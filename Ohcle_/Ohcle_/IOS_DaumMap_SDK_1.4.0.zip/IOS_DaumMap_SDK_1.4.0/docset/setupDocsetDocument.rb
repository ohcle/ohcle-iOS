#!/usr/bin/env ruby

require 'fileutils'

system("cp -r ./*.docset ~/Library/Developer/Shared/Documentation/DocSets")