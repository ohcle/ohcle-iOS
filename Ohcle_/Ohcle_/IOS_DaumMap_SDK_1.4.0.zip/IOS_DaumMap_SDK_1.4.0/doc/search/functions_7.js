var searchData=
[
  ['initwithmappoint_3awithdelegate_3awithopenapikey_3a',['initWithMapPoint:withDelegate:withOpenAPIKey:',['../interface_m_t_map_reverse_geo_coder.html#a848f92692b8d3d9d3d6253a4ba4b349e',1,'MTMapReverseGeoCoder']]],
  ['ismaptilepersistentcacheenabled',['isMapTilePersistentCacheEnabled',['../interface_m_t_map_view.html#ae0ce2f26e663a6aa98c80533be28dae2',1,'MTMapView']]]
];
