var searchData=
[
  ['radius',['radius',['../interface_m_t_map_location_marker_item.html#a0790a81ef3447d5bfa668c754e7d0f8d',1,'MTMapLocationMarkerItem']]],
  ['rotation',['rotation',['../interface_m_t_map_p_o_i_item.html#a2c409ee5f11abbbf6db99b1246b38324',1,'MTMapPOIItem']]]
];
