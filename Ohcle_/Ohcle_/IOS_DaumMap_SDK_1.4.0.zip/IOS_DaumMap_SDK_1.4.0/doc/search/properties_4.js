var searchData=
[
  ['imagenameofcalloutballoonleftside',['imageNameOfCalloutBalloonLeftSide',['../interface_m_t_map_p_o_i_item.html#a65358cce2be2f90e76fa44fbf154a9c4',1,'MTMapPOIItem']]],
  ['imagenameofcalloutballoonrightside',['imageNameOfCalloutBalloonRightSide',['../interface_m_t_map_p_o_i_item.html#a764f2e41794587290a722f52b8aabc06',1,'MTMapPOIItem']]],
  ['itemname',['itemName',['../interface_m_t_map_p_o_i_item.html#a9fd26c178d48e09579253deb2563d693',1,'MTMapPOIItem']]]
];
