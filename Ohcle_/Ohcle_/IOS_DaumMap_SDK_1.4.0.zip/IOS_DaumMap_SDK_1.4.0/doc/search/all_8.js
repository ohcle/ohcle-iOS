var searchData=
[
  ['latitude',['latitude',['../struct_m_t_map_point_geo.html#a0913dd4f2c9da0bc7f02b120116942f0',1,'MTMapPointGeo']]],
  ['longitude',['longitude',['../struct_m_t_map_point_geo.html#a406c6bfec7a7f1ff702d525d52a6b3da',1,'MTMapPointGeo']]]
];
