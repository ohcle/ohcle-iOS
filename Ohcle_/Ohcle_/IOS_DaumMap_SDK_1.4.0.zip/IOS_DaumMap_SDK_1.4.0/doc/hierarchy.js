var hierarchy =
[
    [ "MTMapBounds", "struct_m_t_map_bounds.html", null ],
    [ "MTMapImageOffset", "struct_m_t_map_image_offset.html", null ],
    [ "MTMapPointGeo", "struct_m_t_map_point_geo.html", null ],
    [ "MTMapPointPlain", "struct_m_t_map_point_plain.html", null ],
    [ "NSObject", null, [
      [ "MTMapBoundsRect", "interface_m_t_map_bounds_rect.html", null ],
      [ "MTMapCameraUpdate", "interface_m_t_map_camera_update.html", null ],
      [ "MTMapCircle", "interface_m_t_map_circle.html", null ],
      [ "MTMapLocationMarkerItem", "interface_m_t_map_location_marker_item.html", null ],
      [ "MTMapPOIItem", "interface_m_t_map_p_o_i_item.html", null ],
      [ "MTMapPoint", "interface_m_t_map_point.html", null ],
      [ "MTMapPolyline", "interface_m_t_map_polyline.html", null ],
      [ "MTMapReverseGeoCoder", "interface_m_t_map_reverse_geo_coder.html", null ]
    ] ],
    [ "<NSObjectNSObject>", null, [
      [ "<MTMapReverseGeoCoderDelegate >", "protocol_m_t_map_reverse_geo_coder_delegate_01-p.html", null ]
    ] ],
    [ "UIView", null, [
      [ "MTMapView", "interface_m_t_map_view.html", null ]
    ] ],
    [ "<UIViewNSObject>", null, [
      [ "<MTMapViewDelegate >", "protocol_m_t_map_view_delegate_01-p.html", null ]
    ] ]
];