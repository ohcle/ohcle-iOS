var interface_m_t_map_p_o_i_item =
[
    [ "move:withAnimation:", "interface_m_t_map_p_o_i_item.html#a364a0e420b94c8f4dbc9e18adcf653b7", null ],
    [ "itemName", "interface_m_t_map_p_o_i_item.html#a9fd26c178d48e09579253deb2563d693", null ],
    [ "mapPoint", "interface_m_t_map_p_o_i_item.html#a6d12d2359404960b191ffc4eb8435cb6", null ],
    [ "markerType", "interface_m_t_map_p_o_i_item.html#a85034215286f6bd351154c637c986418", null ],
    [ "markerSelectedType", "interface_m_t_map_p_o_i_item.html#a80b558c79e90288637cfd705688f5338", null ],
    [ "showAnimationType", "interface_m_t_map_p_o_i_item.html#adbf4aad289004696778cb8ffadffd266", null ],
    [ "showDisclosureButtonOnCalloutBalloon", "interface_m_t_map_p_o_i_item.html#af99e25e115cf38a9901e4045a5bd7485", null ],
    [ "draggable", "interface_m_t_map_p_o_i_item.html#a5e28b74993f5670ca64fcdf723f4e08a", null ],
    [ "tag", "interface_m_t_map_p_o_i_item.html#a01c868d7961d050540157c6f347282db", null ],
    [ "userObject", "interface_m_t_map_p_o_i_item.html#a86c52a64c0d6148b5c2c34eead0a398f", null ],
    [ "customImageName", "interface_m_t_map_p_o_i_item.html#a4d863d337cb18b03f31a034665b9f913", null ],
    [ "customSelectedImageName", "interface_m_t_map_p_o_i_item.html#ae9708b80c27c6adbd15c2dd71eb3c2e6", null ],
    [ "customImage", "interface_m_t_map_p_o_i_item.html#ac53f69852c43c1b3ae707727bc4cd1e5", null ],
    [ "customSelectedImage", "interface_m_t_map_p_o_i_item.html#a53d22db2a5211e4e1f2e5d59c2d421bd", null ],
    [ "imageNameOfCalloutBalloonLeftSide", "interface_m_t_map_p_o_i_item.html#a65358cce2be2f90e76fa44fbf154a9c4", null ],
    [ "imageNameOfCalloutBalloonRightSide", "interface_m_t_map_p_o_i_item.html#a764f2e41794587290a722f52b8aabc06", null ],
    [ "customImageAnchorPointOffset", "interface_m_t_map_p_o_i_item.html#ae35acc26449ac012a3cb7e840e78df0e", null ],
    [ "customCalloutBalloonView", "interface_m_t_map_p_o_i_item.html#a760de86ec5597a506d162c0730afdccb", null ],
    [ "customHighlightedCalloutBalloonView", "interface_m_t_map_p_o_i_item.html#ab51d4ddf6a0f34a1561f8a0693f7af36", null ],
    [ "rotation", "interface_m_t_map_p_o_i_item.html#a2c409ee5f11abbbf6db99b1246b38324", null ]
];