var protocol_m_t_map_reverse_geo_coder_delegate_01_p =
[
    [ "MTMapReverseGeoCoder:foundAddress:", "protocol_m_t_map_reverse_geo_coder_delegate_01-p.html#a8fda3042be5eee7d0bb41648ecfb1a07", null ],
    [ "MTMapReverseGeoCoder:failedToFindAddressWithError:", "protocol_m_t_map_reverse_geo_coder_delegate_01-p.html#a3426e1a60859560c98e39c89466605c0", null ]
];