var _m_t_map_geometry_8h =
[
    [ "MTMapPointGeo", "struct_m_t_map_point_geo.html", "struct_m_t_map_point_geo" ],
    [ "MTMapPointPlain", "struct_m_t_map_point_plain.html", "struct_m_t_map_point_plain" ],
    [ "MTMapPoint", "interface_m_t_map_point.html", "interface_m_t_map_point" ],
    [ "MTMapBounds", "struct_m_t_map_bounds.html", "struct_m_t_map_bounds" ],
    [ "MTMapBoundsRect", "interface_m_t_map_bounds_rect.html", "interface_m_t_map_bounds_rect" ],
    [ "MTMapImageOffset", "struct_m_t_map_image_offset.html", "struct_m_t_map_image_offset" ],
    [ "MTMapPointGeoMake", "_m_t_map_geometry_8h.html#a0ddee2a3ab676ce25cca112d2713601d", null ],
    [ "MTMapPointPlainMake", "_m_t_map_geometry_8h.html#a3555e5d7620853910997800eab50e3d4", null ],
    [ "MTMapBoundsMake", "_m_t_map_geometry_8h.html#aa8ceeaaf22e38de11c13dadf6db58955", null ],
    [ "MTMapImageOffsetMake", "_m_t_map_geometry_8h.html#ae5d2457668966748d7b178be9ec913e2", null ],
    [ "MTMapLocationAccuracy", "_m_t_map_geometry_8h.html#a29b37c5bdaaf66c9b2a70b71640eaf30", null ],
    [ "MTMapRotationAngle", "_m_t_map_geometry_8h.html#a1789cdf5a8629d538ea6a4ecac695855", null ]
];