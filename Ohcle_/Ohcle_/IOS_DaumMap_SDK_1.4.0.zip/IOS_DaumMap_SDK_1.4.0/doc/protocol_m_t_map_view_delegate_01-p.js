var protocol_m_t_map_view_delegate_01_p =
[
    [ "mapView:openAPIKeyAuthenticationResultCode:resultMessage:", "protocol_m_t_map_view_delegate_01-p.html#a12d8e0003572ae7e057823dc227bb447", null ],
    [ "mapView:centerPointMovedTo:", "protocol_m_t_map_view_delegate_01-p.html#a7dbc3d9a883c4214cffc8c2ef5464d8e", null ],
    [ "mapView:finishedMapMoveAnimation:", "protocol_m_t_map_view_delegate_01-p.html#a9439a54229914020d7de98ca33dff8cd", null ],
    [ "mapView:zoomLevelChangedTo:", "protocol_m_t_map_view_delegate_01-p.html#aaf49c9aed7f05b7ce8b25a950cc78a67", null ],
    [ "mapView:singleTapOnMapPoint:", "protocol_m_t_map_view_delegate_01-p.html#a9ebe0b05569f5f0b4ffc105d4aa1f94e", null ],
    [ "mapView:doubleTapOnMapPoint:", "protocol_m_t_map_view_delegate_01-p.html#af5b35f507e8ef0b56d64b4406b2a8319", null ],
    [ "mapView:dragStartedOnMapPoint:", "protocol_m_t_map_view_delegate_01-p.html#af23bc171c06e6721acc70f4a8a952735", null ],
    [ "mapView:dragEndedOnMapPoint:", "protocol_m_t_map_view_delegate_01-p.html#a6b750056e9c0f15c1921c46dc713fcbb", null ],
    [ "mapView:longPressOnMapPoint:", "protocol_m_t_map_view_delegate_01-p.html#ae9dad4560698f388132ce31bc783c71a", null ],
    [ "mapView:updateCurrentLocation:withAccuracy:", "protocol_m_t_map_view_delegate_01-p.html#a2c714bbae7a1c08ac61d6dc6c0eda498", null ],
    [ "mapView:failedUpdatingCurrentLocationWithError:", "protocol_m_t_map_view_delegate_01-p.html#a5ac7670485e71749637db50e4570f025", null ],
    [ "mapView:updateDeviceHeading:", "protocol_m_t_map_view_delegate_01-p.html#a3d2ede6056d364d40b37c6832ea31f91", null ],
    [ "mapView:selectedPOIItem:", "protocol_m_t_map_view_delegate_01-p.html#a38293cdab22af41aabe2dafd4b77e7ff", null ],
    [ "mapView:touchedCalloutBalloonOfPOIItem:", "protocol_m_t_map_view_delegate_01-p.html#ac685dab16d67e0d05c97666f0f82d326", null ],
    [ "mapView:touchedCalloutBalloonLeftSideOfPOIItem:", "protocol_m_t_map_view_delegate_01-p.html#a22609e7e5c37988cbd09e7358d646031", null ],
    [ "mapView:touchedCalloutBalloonRightSideOfPOIItem:", "protocol_m_t_map_view_delegate_01-p.html#ab34df1d7777be50c82331c6098af41b3", null ],
    [ "mapView:draggablePOIItem:movedToNewMapPoint:", "protocol_m_t_map_view_delegate_01-p.html#af9f1592d2f3671b3f2b78c87fc5cb53e", null ]
];